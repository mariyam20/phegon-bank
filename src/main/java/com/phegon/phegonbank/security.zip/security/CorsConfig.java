package com.phegon.phegonbank.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
public class CorsConfig {

    @Bean
    public CorsFilter corsFilter(){
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();

        config.addAllowedOrigin("*"); //in production we will only allow origins from out trusred frortend
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");
        config.setMaxAge( 3600L);

        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);

    }
}
